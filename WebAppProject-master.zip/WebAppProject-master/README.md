# Steps
- Create build job in jenkins
- Create test job in jenkins
- Dockerize the project
- Create deploy job in jenkins
- Create start/stop jobs in jenkins
- Add selenium tests to project
- Add cucumber tests to project