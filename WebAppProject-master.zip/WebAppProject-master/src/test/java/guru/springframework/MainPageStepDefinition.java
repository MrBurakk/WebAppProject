package guru.springframework;

public class MainPageStepDefinition {

}
