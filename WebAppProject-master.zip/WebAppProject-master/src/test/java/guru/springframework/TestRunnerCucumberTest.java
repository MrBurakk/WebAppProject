package guru.springframework;

public abstract class TestRunnerCucumberTest {

}
